#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

python test.py \
  --checkpoint m1_logs/best.pth \
  --sam_checkpoint /data/ckpt_files/sam_ckpt/sam3.pt \
  --test_data_dir /data/RGB-T-dataset/Seal/test \
  --save_dir m1_test_maps \
  "$@"

python evaluate3.py \
  --pred_root m1_test_maps \
  --gt_dir /data/RGB-T-dataset/Seal/test/GT
