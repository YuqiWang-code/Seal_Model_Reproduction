#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# 按这台机器上的实际路径修改下面三项。SAM3 权重和数据集不在这个包里。
python train.py \
  --checkpoint /data/ckpt_files/sam_ckpt/sam3.pt \
  --train_data_dir /data/RGB-T-dataset/Seal/train \
  --val_data_dir /data/RGB-T-dataset/Seal/val \
  --save_path m1_logs \
  "$@"
