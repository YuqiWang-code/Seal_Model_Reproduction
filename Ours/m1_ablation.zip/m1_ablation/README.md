# M1 消融

这个包只跑一种设定：不用 RGB LoRA、T LoRA 和 LoRA3，两路图像共用一份冻结的原始 SAM3，只训练 M1。

不包含 SAM3 权重和数据集。目录约定与原来的训练脚本相同：

```
<split>/RGB/*.jpg
<split>/T/*.tif
<split>/box/*.txt
<split>/GT/*.png
```

训练集、验证集、测试集都要有 GT。

## 环境

```bash
pip install -r requirements.txt
```

需要一块支持 bfloat16 的 NVIDIA GPU。`train.py` 默认占用 `CUDA_VISIBLE_DEVICES=0`，`test.py` 默认占用 `1`。要换卡，先导出环境变量再启动。

## 训练

```bash
bash run_train.sh
```

或者：

```bash
python train.py \
  --checkpoint /data/ckpt_files/sam_ckpt/sam3.pt \
  --train_data_dir /data/RGB-T-dataset/Seal/train \
  --val_data_dir /data/RGB-T-dataset/Seal/val \
  --save_path m1_logs
```

直接运行 `python train.py` 就是这个消融。验证 IoU 最高的权重量在 `m1_logs/best.pth`，里面只有 M1。日志在 `m1_logs/train.log`。

## 测试和指标

```bash
bash run_test.sh
```

预测图写到 `m1_test_maps/`。`evaluate3.py` 输出 S、F、E、MAE、IoU、F1、Pd、Fa。GT 不在默认路径时：

```bash
python evaluate3.py --pred_root m1_test_maps --gt_dir /你的路径/test/GT
```
